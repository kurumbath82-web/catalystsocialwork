// You can add interactivity here if needed.
// Example: Show alert on page load
// alert("Welcome to Catalyst Social Work Services!");
